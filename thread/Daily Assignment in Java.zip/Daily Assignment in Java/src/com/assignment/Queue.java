package com.assignment;

import java.util.PriorityQueue;

public class Queue {
    public static void main(String[] args) {
        PriorityQueue<String> str = new PriorityQueue<String>();
         str.add("Pratiksha");
         str.add("ishika");
         str.add("divya");
         str.add("nano");
         System.out.println("Head:" + str.element());
       //  System.out



    }
}
