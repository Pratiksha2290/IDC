package com.assignment;
import java.util.*;

import java.util.Comparator;

public class EmployeeTM {
    public static void main(String[] args) {
    }











        //TreeMap<EmployeeTM,Integer > Employee = new TreeMap<>(new Comparator<EmployeeTM>() {
          //  @Override
            //public int compare(EmployeeTM o1, EmployeeTM o2) {
              //  Integer Emp_ID1 = o1.getEmp_ID();
                //Integer  Emp_ID2 = o2.getEmp_ID();

                //return Emp_ID1.compareTo(Emp_ID2);
            //}
        //});

       // Employee.put(new EmployeeTM(100,"A"),30);












    }



